﻿create database btl
go
use btl
go
CREATE TABLE NHOMTHUOC(
   nhomThuoc  VARCHAR (20) primary key,
   moTa NVARCHAR (30) NOT NULL,     
);
CREATE TABLE DonViTinh(
	donViTinh VARCHAR (20) primary key,
   moTa NVARCHAR (30) NOT NULL,     
);
CREATE TABLE Thuoc(
   maThuoc  NVARCHAR (30) primary key,
   ten NVARCHAR (50)  NULL,
   donViQuyDoi NVARCHAR (50)  NULL,
   giaNhap float,
   giaBan float,
   donViTinh  VARCHAR (20) NULL, 
   Constraint F_dvt Foreign key(donViTinh) references DonViTinh(donViTinh),
   nhomThuoc  VARCHAR (20) NULL, 
   Constraint F_NT Foreign key(nhomThuoc) references NHOMTHUOC(nhomThuoc),
);
	insert Thuoc values ('MT100', 'ADVIL', 'Thung', '15000', '25000', 'Kg', 'NT1')
	INSERT Thuoc VALUES ('MT101', 'ADVIL', 'Hop', '20000', '25000', 'Vi', 'NT3')
	INSERT Thuoc VALUES ('MT102', 'ASPIRIN', 'Hop', '20000', '22000', 'Vi', 'NT1')
	INSERT Thuoc VALUES ('MT103', 'CELECOXIB', 'Thung', '25000', '30000', 'Vi', 'NT3')
	INSERT Thuoc VALUES ('MT104', 'CELECOXIB', 'Hop', '25000', '27000', 'Vi', 'NT3')
	INSERT Thuoc VALUES ('MT105', 'CELECOXIB', 'Hop', '15000', '20000', 'Vi', 'NT3')
	INSERT Thuoc VALUES ('MT106', 'CELECOXIB', 'Thung', '15000', '35000', 'Kg', 'NT3')
	INSERT Thuoc VALUES ('MT107', 'DICLOFENAC', 'Chiec', '10000', '40000', 'Viên', 'NT2')
	INSERT Thuoc VALUES ('MT108', 'NAPROXEN', 'Hop', '10000', '25000', 'Viên', 'NT1')
	INSERT Thuoc VALUES ('MT109', 'NAPROXEN', 'Hop', '25000', '27000', 'Kg', 'NT1')
	INSERT Thuoc VALUES ('MT110', 'NAPROXEN', 'Hop', '20000', '25000', 'Lon', 'NT2')
	INSERT Thuoc VALUES ('MT111', 'PANADOL', 'Thung', '15000', '40000', 'Viên', 'NT2')
	INSERT Thuoc VALUES ('MT112', 'PARACETAMOL', 'Chiec', '15000', '20000', 'Vi', 'NT2')
	INSERT Thuoc VALUES ('MT113', 'PARACETAMOL', 'Hop', '12000', '40000', 'Lon', 'NT3')
	INSERT Thuoc VALUES ('MT114', 'PARACETAMOL', 'Hop', '15000', '40000', 'Kg', 'NT1')
	INSERT Thuoc VALUES ('MT115', 'PARACETAMOL', 'Thung', '10000', '35000', 'Viên', 'NT3')
	INSERT Thuoc VALUES ('MT116', 'PARACETAMOL', 'Chiec', '20000', '25000', 'Viên', 'NT3')
	INSERT Thuoc VALUES ('MT117', 'PARACETAMOL', 'Thung', '25000', '30000', 'Vi', 'NT1')
	INSERT Thuoc VALUES ('MT118', 'TRAMADOL', 'Hop', '10000', '30000', 'Kg', 'NT1')
	INSERT Thuoc VALUES ('MT119', 'TRAMADOL', 'Hop', '10000', '35000', 'Vi', 'NT3')
	INSERT Thuoc VALUES ('MT120', 'TYLENOL', 'Hop', '25000', '40000', 'Cái', 'NT3')
	INSERT Thuoc VALUES ('MT121', 'TYLENOL', 'Thung', '20000', '35000', 'Vi', 'NT1')
	INSERT Thuoc VALUES ('MT122', 'TYLENOL', 'Chiec', '25000', '20000', 'Cái', 'NT1')
	INSERT Thuoc VALUES ('MT200', 'ADVIL', 'Hop', '15000', '25000', 'Vi', 'NT3')
	INSERT Thuoc VALUES ('MT201', 'ADVIL', 'Hop', '10000', '30000', 'Viên', 'NT1')
	INSERT Thuoc VALUES ('MT202', 'ADVIL', 'Thung', '10000', '25000', 'Viên', 'NT1')
	INSERT Thuoc VALUES ('MT203', 'CELECOXIB', 'Chiec', '12000', '40000', 'Vi', 'NT3')
	INSERT Thuoc VALUES ('MT204', 'CELECOXIB', 'Hop', '20000', '20000', 'Kg', 'NT3')
	INSERT Thuoc VALUES ('MT205', 'DICLOFENAC', 'Hop', '25000', '35000', 'Viên', 'NT3')
	INSERT Thuoc VALUES ('MT206', 'DICLOFENAC', 'Hop', '25000', '40000', 'Vi', 'NT1')
	INSERT Thuoc VALUES ('MT207', 'DICLOFENAC', 'Thung', '20000', '25000', 'Viên', 'NT2')
	INSERT Thuoc VALUES ('MT208', 'IBUPROFEN', 'Thung', '10000', '35000', 'Cái', 'NT2')
	INSERT Thuoc VALUES ('MT209', 'IBUPROFEN', 'Thung', '15000', '20000', 'Kg', 'NT3')
	INSERT Thuoc VALUES ('MT210', 'IBUPROFEN', 'Chiec', '12000', '30000', 'Viên', 'NT1')
	INSERT Thuoc VALUES ('MT211', 'NAPROXEN', 'Hop', '20000', '40000', 'Kg', 'NT3')
	INSERT Thuoc VALUES ('MT212', 'PANADOL', 'Thung', '10000', '40000', 'Viên', 'NT2')
	INSERT Thuoc VALUES ('MT213', 'PARACETAMOL', 'Chiec', '25000', '27000', 'Vi', 'NT3')
	INSERT Thuoc VALUES ('MT214', 'PARACETAMOL', 'Thung', '10000', '40000', 'Vi', 'NT1')
	INSERT Thuoc VALUES ('MT215', 'PARACETAMOL', 'Hop', '10000', '40000', 'Kg', 'NT3')
	INSERT Thuoc VALUES ('MT216', 'TRAMADOL', 'Hop', '10000', '20000', 'Cái', 'NT2')
	INSERT Thuoc VALUES ('MT217', 'TRAMADOL', 'Thung', '12000', '35000', 'Vi', 'NT1')
	INSERT Thuoc VALUES ('MT218', 'TRAMADOL', 'Chiec', '10000', '25000', 'Kg', 'NT2')
	INSERT Thuoc VALUES ('MT219', 'TRAMADOL', 'Thung', '20000', '40000', 'Vi', 'NT1')
	INSERT Thuoc VALUES ('MT220', 'TYLENOL', 'Hop', '25000', '25000', 'Viên', 'NT3')
	INSERT Thuoc VALUES ('MT300', 'ADVIL', 'Thung', '10000', '25000', 'Viên', 'NT3')
	INSERT Thuoc VALUES ('MT301', 'ADVIL', 'Chiec', '15000', '20000', 'Kg', 'NT3')
	INSERT Thuoc VALUES ('MT302', 'ASPIRIN', 'Hop', '15000', '40000', 'Cái', 'NT3')
	INSERT Thuoc VALUES ('MT303', 'ASPIRIN', 'Thung', '20000', '20000', 'Viên', 'NT2')
	INSERT Thuoc VALUES ('MT304', 'ASPIRIN', 'Chiec', '12000', '30000', 'Vi', 'NT3')
	INSERT Thuoc VALUES ('MT305', 'CELECOXIB', 'Thung', '12000', '40000', 'Cái', 'NT2')
	INSERT Thuoc VALUES ('MT306', 'CELECOXIB', 'Thung', '15000', '25000', 'Vi', 'NT1')
	INSERT Thuoc VALUES ('MT307', 'CELECOXIB', 'Thung', '10000', '20000', 'Kg', 'NT2')
	INSERT Thuoc VALUES ('MT308', 'CELECOXIB', 'Hop', '10000', '40000', 'Viên', 'NT1')
	INSERT Thuoc VALUES ('MT309', 'CELECOXIB', 'Chiec', '12000', '25000', 'Viên', 'NT2')
	INSERT Thuoc VALUES ('MT310', 'DICLOFENAC', 'Hop', '25000', '25000', 'Viên', 'NT2')
	INSERT Thuoc VALUES ('MT311', 'IBUPROFEN', 'Thung', '10000', '30000', 'Vi', 'NT2')
	INSERT Thuoc VALUES ('MT312', 'IBUPROFEN', 'Thung', '12000', '30000', 'Vi', 'NT2')
	INSERT Thuoc VALUES ('MT313', 'NAPROXEN', 'Chiec', '20000', '40000', 'Vi', 'NT2')
	INSERT Thuoc VALUES ('MT314', 'NAPROXEN', 'Hop', '20000', '20000', 'Vi', 'NT3')
	INSERT Thuoc VALUES ('MT315', 'NAPROXEN', 'Thung', '20000', '35000', 'Kg', 'NT2')
	INSERT Thuoc VALUES ('MT316', 'NAPROXEN', 'Chiec', '20000', '40000', 'Viên', 'NT2')
	INSERT Thuoc VALUES ('MT317', 'PANADOL', 'Hop', '10000', '25000', 'Vi', 'NT3')
	INSERT Thuoc VALUES ('MT318', 'PANADOL', 'Thung', '15000', '35000', 'Cái', 'NT1')
	INSERT Thuoc VALUES ('MT319', 'PANADOL', 'Thung', '25000', '35000', 'Kg', 'NT2')
	INSERT Thuoc VALUES ('MT320', 'PANADOL', 'Hop', '12000', '40000', 'Kg', 'NT1')
	INSERT Thuoc VALUES ('MT321', 'PARACETAMOL', 'Hop', '12000', '20000', 'Kg', 'NT1')
	INSERT Thuoc VALUES ('MT322', 'TRAMADOL', 'Thung', '15000', '25000', 'Kg', 'NT3')
	INSERT Thuoc VALUES ('MT323', 'TRAMADOL', 'Chiec', '25000', '29000', 'Viên', 'NT1')
	INSERT Thuoc VALUES ('MT324', 'TRAMADOL', 'Hop', '20000', '40000', 'Viên', 'NT2')
	INSERT Thuoc VALUES ('MT325', 'TRAMADOL', 'Thung', '15000', '25000', 'Vi', 'NT1')
	
	insert NhanVien values ('20011221', 'Ha Quoc', 'Long', '21', '0', '690960')
	insert NhanVien values ('21004195', 'Huynh Cong', 'Vuong', '20', '0', '900000')
	insert NhanVien values ('21001715', 'Duong Ngo', 'Manh', '20', '0', '900000')
	insert NhanVien values ('21003345', 'Nguyen Tran nhat', 'Minh', '20', '0', '1000000')
CREATE TABLE NhaCungCap(
	maNhaCungCap NVARCHAR (20) primary key,
	tenNhaCungCap NVARCHAR (50) ,
	SDTNhaCungCap NVARCHAR (20),
	diaChiNhaCungCap NVARCHAR (100),
	STKNhaCungCap NVARCHAR (20),
	FAXNhaCungCap NVARCHAR (20),
);
INSERT NhaCungCap VALUES ('NCC01', 'Farmacity', '0912345678', '17 Go Vap', '0123456789122', '.8422222222')
INSERT NhaCungCap VALUES ('NCC02', 'Farmacity', '0912345678', '232 Hoang Chung', '0123456789122', '.8422222222')
INSERT NhaCungCap VALUES ('NCC03', 'Thuoclongan', '0936861622', '96 Nguyen Dinh Chieu', '0123456789122', '.8422222222')
INSERT NhaCungCap VALUES ('NCC04', 'Thuoclongchau', '0942574179', '450 Nguyen Dinh Chieu', '0123456789122', '.8422222222')
INSERT NhaCungCap VALUES ('NCC05', 'Thuocbinhduong', '0981833745', '107 Vo Cong Ton', '0123456789122', '.8422222222')
INSERT NhaCungCap VALUES ('NCC06', 'Thuocminhha', '0965046332', 'Cho Hau Nghia', '0123456789122', '.8422222222')

CREATE TABLE phieuNhapHang (
	maPhieu NVARCHAR (20) primary key,
	maNhaCungCap NVARCHAR (20),
	foreign key (maNhaCungCap) references NhaCungCap(maNhaCungCap), 
	tenNhaCungCap NVARCHAR (50),
	maThuoc NVARCHAR (30),
	foreign key (maThuoc) references Thuoc (maThuoc),
	tenThuoc NVARCHAR (50),
	soLuongThuocNhap INT,
);
create table khoangchi (
	stt INT primary key,
	maPhieu NVARCHAR(20) foreign key references phieuNhapHang(maPhieu),
	manhacungcap nvarchar(20),
	tennhacungcap nvarchar(50),
	mathuoc nvarchar(30),
	tenthuoc nvarchar(30),
	soluong INT,
	gianhap float,
	khoangchi FLOAT,

);
CREATE TABLE PhieuBanHang (
	maPhieu NVARCHAR (20) primary key,
	mathuoc NVARCHAR (30),
	Foreign key(mathuoc) references Thuoc(maThuoc),
	tenthuoc NVARCHAR (50),
	soLuongThuoc INT,
);
create table khoangthu (
	stt INT primary key,

	maPhieu NVARCHAR(20) foreign key references phieuBanHang(maPhieu),
	mathuoc nvarchar(30),
	tenthuoc nvarchar(30),
	soluong INT,

	giaNhap float,
	giaBan float,
	khoangthu FLOAT,
);
create table dangnhap (
	taikhoan NVARCHAR (20) primary key,
	matkhau NVARCHAR (20),
);
	Insert dangnhap values ('sa','12345678')

	INSERT NHOMTHUOC VALUES ('NT1', 'NHOMTHUOC1')
	INSERT NHOMTHUOC VALUES ('NT2', 'NHOMTHUOC2')
	INSERT NHOMTHUOC VALUES ('NT3', 'NHOMTHUOC3')

	INSERT DonViTinh VALUES ('Cái', '')
	INSERT DonViTinh VALUES ('Vi', '')
	INSERT DonViTinh VALUES ('Lon', '')
	INSERT DonViTinh VALUES ('Kg', '')
	INSERT DonViTinh VALUES ('Viên', '')

CREATE TABLE NhanVien(
   maNV  NVARCHAR (30) primary key,
   ho NVARCHAR (50)  NULL,
   ten NVARCHAR (50)  NULL,
   tuoi int NULL,
   phai bit  NULL,
   tienLuong float,
);

